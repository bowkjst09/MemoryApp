# memory-sqlite-demo
- This tutorial we will save text from EditText and Image from gallery into SQLite database. So here is the complete step by step tutorial for Insert data into SQLite database in android using EditText and ImageView and then show all data to custom gridview.
- Video tutorials: https://goo.gl/oyQFsh
- Demo:

> ![alt tag](https://github.com/quocnguyenvan/memory-sqlite-demo/blob/master/demo/food_sqlite.png)

